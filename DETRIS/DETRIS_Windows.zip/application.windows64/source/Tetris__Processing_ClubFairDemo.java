import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Tetris__Processing_ClubFairDemo extends PApplet {

//©2019 Dylan Speiser



final static String TITLE = "DETRIS";

Table scores;

Game game;
Piece piece;
UndertaleKeyboard keyboard = new UndertaleKeyboard();
SoundFile music1;
SoundFile music2;
SoundFile music3;
SoundFile musicDeath;
Tetromino tetromino = new Tetromino();
Tetromino activet = new Tetromino();
int timer = 0;
int colorTimer = 0;
int count = 0;
int lost = 0;
int stage = 0;

PFont f;
PFont d;

PImage Line;
PImage L;
PImage J;
PImage Square;
PImage S;
PImage T;
PImage Z;

public void setup() {
  scores = loadTable("data/highscores.csv", "header");
  scores.setColumnType(1,"int");
  scores.sortReverse(1);
  saveTable(scores, "data/highscores.csv");
  scores = loadTable("data/highscores.csv", "header");
  for (int i = 0; i<=scores.lastRowIndex(); i++) {
    //println(scores.getStringRow(i));
  }
  PImage titlebaricon = loadImage("icon.png");
  surface.setIcon(titlebaricon);
  changeAppTitle(TITLE);
  
  game = new Game();
  piece = new Piece();
  f = createFont("Determination Mono",30,true);
  d = createFont("Determination Mono",30,true);
  
  music1 = new SoundFile(this, "data/Music1.mp3");
  music2 = new SoundFile(this, "data/Music2.mp3");
  music3 = new SoundFile(this, "data/Music3.mp3");
  musicDeath = new SoundFile(this, "data/MusicDeath.mp3");
  
  Line = loadImage("data/Line.png");
  L = loadImage("data/L.png");
  J = loadImage("data/J.png");
  Square = loadImage("data/Square.png");
  S = loadImage("data/S.png");
  T = loadImage("data/T.png");
  Z = loadImage("data/Z.png");

  
  println("Done loading media");

  
  //background(0);
  noStroke();
  fill(102);
  
  keyboard.keyboardSetup();
}

public void draw() {
  if (keyboard.gotten == false) {
    keyboard.keyboardDraw();
  } else {
    if (lost == 0) {
      if (stage == 0 || stage == 2) {
        background(0);
      } else if (stage == 1) {
        colorMode(HSB);
        background(colorTimer%360,255,255);
        colorMode(RGB);
      }
      game.drawBoard();
      game.drawPieces();
      game.drawBoard();
  
      everySecond();
              debug(false);
      game.showGhostPiece(true);
      
      if (game.collisionDetection(activet) == true) {
        if (activet.solidifyNext == 0) {
          activet.solidify();
        }
      }
      
      for (int i = 0; i<20; i++) {
          if (game.OccupiedSpaces[i][0] != 0 && game.OccupiedSpaces[i][1] != 0 && game.OccupiedSpaces[i][2] != 0 && game.OccupiedSpaces[i][3] != 0 && game.OccupiedSpaces[i][4] != 0 && game.OccupiedSpaces[i][5] != 0 && game.OccupiedSpaces[i][6] != 0 && game.OccupiedSpaces[i][7] != 0 && game.OccupiedSpaces[i][8] != 0 && game.OccupiedSpaces[i][9] != 0) {
            game.lineClear(i);
          }
      }
        
      if (game.OccupiedSpaces[0][activet.tile1.posy]!=0 || game.OccupiedSpaces[0][activet.tile2.posy]!=0 || game.OccupiedSpaces[0][activet.tile3.posy]!=0 || game.OccupiedSpaces[0][activet.tile4.posy]!=0) {
        game.lose();
      }
      
      //if (game.OccupiedSpaces[activet.tile1.posx][activet.tile1.posy]!=0 || game.OccupiedSpaces[activet.tile2.posx][activet.tile2.posy]!=0 || game.OccupiedSpaces[activet.tile3.posx][activet.tile3.posy]!=0 || game.OccupiedSpaces[activet.tile4.posx][activet.tile4.posy]!=0) {
      //  game.lose();
      //}
      
      noFill();
      stroke(255);
      strokeWeight(4);
      rect(game.BoardOrigin.x,game.BoardOrigin.y,game.BoardWidth,game.BoardHeight);
      
      if ((game.score > 1000 && game.score < 2000) && game.penultimateTriggered == false) {
        game.penultimate();
      } 
      
      if ((game.score > 2000) && game.finaleTriggered == false) {
        game.finale();
      }
      
      colorTimer+=1.6f;
      timer++;
      println(activet.solidifyNext);
    }
  }
}

//©2019 Dylan Speiser

public void debug(boolean on) {
  if (on) {
      for (int i = 0; i<10; i++) {
        strokeWeight(2);
        line(game.BoardOrigin.x+(40*i),game.BoardOrigin.y,game.BoardOrigin.x+(40*i),game.BoardOrigin.y+game.BoardHeight);
      }
      
      for (int j = 0; j<20; j++) {
        strokeWeight(2);
        line(game.BoardOrigin.x,game.BoardOrigin.y+(40*j),game.BoardOrigin.x+game.BoardWidth,game.BoardOrigin.y+(40*j));
      }
      
      for (int i = 0; i<10; i++) {
        for (int j = 0; j<20; j++) {
          strokeWeight(0);
          fill(255,0,0);
          ellipse(game.TilePosX[j][i],game.TilePosY[j][i],8,8);
        }
      }
      
      fill(0);
      text("1",game.TilePosX[activet.tile1.posx][activet.tile1.posy]+11,game.TilePosY[activet.tile1.posx][activet.tile1.posy]+30);
      text("2",game.TilePosX[activet.tile2.posx][activet.tile2.posy]+11,game.TilePosY[activet.tile2.posx][activet.tile2.posy]+30);
      text("3",game.TilePosX[activet.tile3.posx][activet.tile3.posy]+11,game.TilePosY[activet.tile3.posx][activet.tile3.posy]+30);
      text("4",game.TilePosX[activet.tile4.posx][activet.tile4.posy]+11,game.TilePosY[activet.tile4.posx][activet.tile4.posy]+30);
      
      fill(255);
      text(activet.rotation,100,100);
      text(game.fallTime,100,130);
      text(game.storedPiece,100,190);
    }
}

public void keyPressed() {
  if (keyboard.gotten == false) {
    keyboard.keyboardPressed();
  } else {
    char pressed = PApplet.parseChar(keyCode);
    //println(keyCode);
    //38 = UP
    //37 = LEFT
    //40 = DOWN
    //39 = RIGHT
    if (pressed == 10) {
        activet.snapDown();
        activet.solidify();
    }
    
    if (pressed == 38) {
        activet.rotate();
    }
    
    if (pressed == 39) {
        activet.moveRight();
    }
    
    if (pressed == 40) {
        if (game.collisionDetection(activet) == true) {
          activet.solidify();
          
        }
        activet.moveDown();
    }
    
    if (pressed == 37) {
        activet.moveLeft();
    }
    
    if (pressed == 16) {
      game.swap();
    }
    
    if (pressed == 10 && lost == 1) {
        game.reset();
    }
  }
}

public Piece newPiece(int type, int posX, int posY) {
  Piece generated;
  generated = new Piece();
  generated.type = type;
  generated.posx = posX;
  generated.posy = posY;
  generated.init();
  return generated;
}

public void changeAppIcon(PImage img) {
  final PGraphics pg = createGraphics(128, 128, JAVA2D);

  pg.beginDraw();
  pg.image(img, 0, 0, 16, 16);
  pg.endDraw();

  frame.setIconImage(pg.image);
}

public void changeAppTitle(String title) {
  surface.setTitle(title);
}

public void everySecond() {
  if (timer > game.fallTime-1) {
    if (game.collisionDetection(activet) == false) {
          activet.moveDown();
       }
    
    //println("Head: " + activet.headPosX + "," + activet.headPosY);
    //println("   1: " + activet.tile1.posy + "," + activet.tile1.posx);
    //println("   2: " + activet.tile2.posy + "," + activet.tile2.posx);
    //println("   3: " + activet.tile3.posy + "," + activet.tile3.posx);
    //println("   4: " + activet.tile4.posy + "," + activet.tile4.posx);
    
    //println(activet.newvalue1y);
    //println(activet.newvalue1x);
    //println(activet.newvalue2y);
    //println(activet.newvalue2x);
    //println(activet.newvalue3y);
    //println(activet.newvalue3x);
    //println(activet.newvalue4y);
    //println(activet.newvalue4x);
    
    if (activet.solidifyNext <= 1) {
      activet.solidifyNext--;
    }
    
     if (activet.solidifyNext > 1) {
       if (game.collisionDetection(activet) == true) {
          activet.solidifyNext=1;
       }
     }
     
    if (game.penultimateTriggered == false && game.finaleTriggered == false) {
      game.fallTime = PApplet.parseInt(map(game.score,0,3000,60,10));
    }
    
    //println(game.fallTime);
    timer = 0;
    count++;
  }
}

public void keyReleased() {
  if (keyboard.gotten == false) {
    if (keyCode == 16) {
      keyboard.doCapitals = false;
    }
  }
}
public class Char {
  int xindex;
  int yindex;
  char face;
  boolean selected;
  
  public void appendToString(String string) {
    keyboard.name.append(face);
    keyboard.nameString = keyboard.name.toString();
  }
}
public class Game {
  Point BoardOrigin;
  int BoardHeight = 800;
  int BoardWidth = 400;
  int fallTime = 60;
  int storedPiece = 0;
  int score = 0;
  int linesCleared = 0;
  int upNext[] = {0,0,0,0,0};
  boolean penultimateTriggered = false;
  boolean finaleTriggered = false;
  String yourScore = "";
 
  int TilePosX[][] = {
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0}
  };
  
  int TilePosY[][] = {
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0}
  };
  
  int OccupiedSpaces[][] = {
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {0,0,0,0,0,0,0,0,0,0,9},
    {9,9,9,9,9,9,9,9,9,9,9}
  };
  
  public void init() {
      BoardOrigin = new Point();
      BoardOrigin.x = (width/2)-BoardWidth/2;
      BoardOrigin.y = (height/2)-BoardHeight/2;
      
      for (int i = 0; i<10; i++) {
        for (int j = 0; j<20; j++) {
          TilePosX[j][i] = BoardOrigin.x+40*i;
          TilePosY[j][i] = BoardOrigin.y+40*j;
        }
      }
      music1.loop();
  }
  
  public void drawBoard() {
      //Main board
      noFill();
      stroke(255);
      strokeWeight(4);
      rect(game.BoardOrigin.x,game.BoardOrigin.y,game.BoardWidth,game.BoardHeight);
      textFont(d,100);
      text("DETRIS",width/2-175,BoardOrigin.y-15);
      
      //Hold box
      noFill();
      stroke(255);
      strokeWeight(4);
      rect(game.BoardOrigin.x-200,game.BoardOrigin.y,200,200);
      fill(255);
      textFont(d,40);
      text("HOLD",game.BoardOrigin.x-145,game.BoardOrigin.y+50);
      
    if (storedPiece==1) {
      //Line
      image(Line,game.BoardOrigin.x-185,game.BoardOrigin.y+110,176,60);
    } else if (storedPiece==2) {
      //L
      image(L,game.BoardOrigin.x-160,game.BoardOrigin.y+85,133,92);
    } else if (storedPiece==3) {
      //J
      image(J,game.BoardOrigin.x-165,game.BoardOrigin.y+80,133,100);
    } else if (storedPiece==4) {
      //Square
      image(Square,game.BoardOrigin.x-148,game.BoardOrigin.y+80,101,99);
    } else if (storedPiece==5) {
      //S
      image(S,game.BoardOrigin.x-170,game.BoardOrigin.y+65,144,120);
    } else if (storedPiece==6) {
      //T
      image(T,game.BoardOrigin.x-168,game.BoardOrigin.y+70,144,103);
    } else if (storedPiece==7) {
      //Z
      image(Z,game.BoardOrigin.x-170,game.BoardOrigin.y+68,144,99);
    }
      
      //Next Up
      noFill();
      stroke(255);
      strokeWeight(4);
      rect(game.BoardOrigin.x+BoardWidth,game.BoardOrigin.y,200,590);
      text("NEXT ",game.BoardOrigin.x+BoardWidth+46,game.BoardOrigin.y+50);
      for (int i=0;i<4;i++) {
        if (upNext[i]==1) {
          //Line
          image(Line,game.BoardOrigin.x+BoardWidth+9+7,(0.52f*i*(game.BoardOrigin.y+110))+200,176,60);
        } else if (upNext[i]==2) {
          //L
          image(L,game.BoardOrigin.x+BoardWidth+27+7,(0.52f*i*(game.BoardOrigin.y+85))+200,133,92);
        } else if (upNext[i]==3) {
          //J
          image(J,game.BoardOrigin.x+BoardWidth+32+7,(0.52f*i*(game.BoardOrigin.y+80))+200,133,100);
        } else if (upNext[i]==4) {
          //Square
          image(Square,game.BoardOrigin.x+BoardWidth+47+7,(0.52f*i*(game.BoardOrigin.y+80))+200,101,99);
        } else if (upNext[i]==5) {
          //S
          image(S,game.BoardOrigin.x+BoardWidth+26+7,(0.52f*i*(game.BoardOrigin.y+65))+200,144,120);
        } else if (upNext[i]==6) {
          //T
          image(T,game.BoardOrigin.x+BoardWidth+24+7,(0.52f*i*(game.BoardOrigin.y+70))+200,144,103);
        } else if (upNext[i]==7) {
          //Z
          image(Z,game.BoardOrigin.x+BoardWidth+26+7,(0.52f*i*(game.BoardOrigin.y+68))+200,144,99);
        }
      }
     
     //SCORE
     noFill();
     stroke(255);
     strokeWeight(4);
     rect(game.BoardOrigin.x-200,game.BoardOrigin.y+200,200,320);
     fill(255);
     textFont(d,40);
     text(keyboard.nameString,(game.BoardOrigin.x-110)-(10*(keyboard.nameString.length())),game.BoardOrigin.y+250);
     line(game.BoardOrigin.x-200,game.BoardOrigin.y+273,game.BoardOrigin.x,game.BoardOrigin.y+273);
     text("SCORE",game.BoardOrigin.x-160,game.BoardOrigin.y+320);
       if (score > 9) {
         text(score,(game.BoardOrigin.x-110)-(15*floor(log(score+1)/2.303f)),game.BoardOrigin.y+365);
       } else {
         text(score,game.BoardOrigin.x-110,game.BoardOrigin.y+365);
       }
     text("LINES",game.BoardOrigin.x-160,game.BoardOrigin.y+440);
       if (linesCleared > 9) {
         text(linesCleared,(game.BoardOrigin.x-110)-(15*floor(log(linesCleared+1)/2.303f)),game.BoardOrigin.y+485);
       } else {
         text(linesCleared,game.BoardOrigin.x-110,game.BoardOrigin.y+485);
       }
     fill(255);
     textFont(d,50);
     text("©2019 Dylan Speiser",(width/2)-285,height-60);
  }
  
  public void drawPieces() {
      for (int i = 0; i<10; i++) {
        for (int j = 0; j<20; j++) {
          render(newPiece(OccupiedSpaces[j][i],j,i));
        }
      }
      
    renderTetromino(activet);
  }
  
  public void render(Piece piece) {
    if (stage==2 && piece.type!=0) {
      fill(color(0xff80ffff));
      stroke(color(0xff089999));
      strokeWeight(2);
      rect(TilePosX[piece.posx][piece.posy],TilePosY[piece.posx][piece.posy],40,40);
    } else {
      fill(piece.Color);
      stroke(piece.strokeColor);
      strokeWeight(2);
      rect(TilePosX[piece.posx][piece.posy],TilePosY[piece.posx][piece.posy],40,40);
    }
  }
  
  public void renderTetromino(Tetromino tettromino) {
    render(tettromino.tile1);
    render(tettromino.tile2);
    render(tettromino.tile3);
    render(tettromino.tile4);
  }
  
  public boolean collisionDetection(Tetromino teetromino) {
    if (OccupiedSpaces[teetromino.tile1.posx+1][teetromino.tile1.posy]!=0 || OccupiedSpaces[teetromino.tile2.posx+1][teetromino.tile2.posy]!=0 || OccupiedSpaces[teetromino.tile3.posx+1][teetromino.tile3.posy]!=0 || OccupiedSpaces[teetromino.tile4.posx+1][teetromino.tile4.posy]!=0) {
      return true;
    } else {
      return false;
    }
  }
  
  //for ghost piece;
  public boolean detectCollision() {
    if (OccupiedSpaces[activet.ghost1.x+1][activet.ghost1.y]!=0 || OccupiedSpaces[activet.ghost2.x+1][activet.ghost2.y]!=0 || OccupiedSpaces[activet.ghost3.x+1][activet.ghost3.y]!=0 || OccupiedSpaces[activet.ghost4.x+1][activet.ghost4.y]!=0) {
      return true;
    } else {
      return false;
    }
  }
  
  public void showGhostPiece(boolean on) {
    if (on) {
      activet.ghost1 = activet.ghost1.newPoint(activet.tile1.posx,activet.tile1.posy);
      activet.ghost2 = activet.ghost2.newPoint(activet.tile2.posx,activet.tile2.posy);
      activet.ghost3 = activet.ghost3.newPoint(activet.tile3.posx,activet.tile3.posy);
      activet.ghost4 = activet.ghost4.newPoint(activet.tile4.posx,activet.tile4.posy);
      
      activet.ghost();
      
      //println(activet.ghost1.x+","+activet.ghost1.y);
      //println(activet.ghost2.x+","+activet.ghost2.y);
      //println(activet.ghost3.x+","+activet.ghost3.y);
      //println(activet.ghost4.x+","+activet.ghost4.y);
      
      if (stage==2 && piece.type!=0) {
        noFill();
        stroke(color(0xff089999));
        strokeWeight(3);
        rect(TilePosX[activet.ghost1.x][activet.ghost1.y],TilePosY[activet.ghost1.x][activet.ghost1.y],40,40);
        rect(TilePosX[activet.ghost2.x][activet.ghost2.y],TilePosY[activet.ghost2.x][activet.ghost2.y],40,40);
        rect(TilePosX[activet.ghost3.x][activet.ghost3.y],TilePosY[activet.ghost3.x][activet.ghost3.y],40,40);
        rect(TilePosX[activet.ghost4.x][activet.ghost4.y],TilePosY[activet.ghost4.x][activet.ghost4.y],40,40);
      } else {
        noFill();
        stroke(activet.tile1.strokeColor);
        strokeWeight(3);
        rect(TilePosX[activet.ghost1.x][activet.ghost1.y],TilePosY[activet.ghost1.x][activet.ghost1.y],40,40);
        rect(TilePosX[activet.ghost2.x][activet.ghost2.y],TilePosY[activet.ghost2.x][activet.ghost2.y],40,40);
        rect(TilePosX[activet.ghost3.x][activet.ghost3.y],TilePosY[activet.ghost3.x][activet.ghost3.y],40,40);
        rect(TilePosX[activet.ghost4.x][activet.ghost4.y],TilePosY[activet.ghost4.x][activet.ghost4.y],40,40);
      }
    }
  }
  
  public void lineClear(int xpos) {
    fill(255);
    noStroke();
    rect(TilePosX[xpos][0],TilePosY[xpos][0],BoardWidth,40);
    for (int i = 0; i<10; i++) {
      OccupiedSpaces[xpos][i] = 0;
    }
    for (int i = xpos; i>0; i--) {
      for (int j = 0; j<10; j++) {
        OccupiedSpaces[i][j] = OccupiedSpaces[i-1][j];
      }
    }
    linesCleared++;
    score+=15;
  }
  
  public void swap() {
    if (storedPiece == 0) {
      storedPiece = activet.type;
      activet = activet.newTetromino(upNext[0]);
    } else {
      int newType = activet.type;
      activet = activet.newTetromino(storedPiece);
      storedPiece = newType;
    }
  }
  
  public void lose() {
    timer = 10000;
    fill(255);
    //text("Lose!",100,160);
    lost=1;
    
    music1.stop();
    music2.stop();
    music3.stop();
    musicDeath.play();
    
    TableRow row = scores.addRow();
    row.setString("name", keyboard.nameString);
    row.setString("score", "0"+score);
    saveTable(scores, "data/highscores.csv");
    scores = loadTable("data/highscores.csv", "header");
    
    noStroke();
    fill(0);
    rect(0,height-110,width,110);
    fill(0,120);
    rect(0,0,width,height);
    
    fill(255);
    textFont(d,56);
    text("SCORES",game.BoardOrigin.x+97,game.BoardOrigin.y+75);
    scores.setColumnType(1,"int");
    scores.sortReverse(1);
    saveTable(scores, "data/highscores.csv");
    scores = loadTable("data/highscores.csv", "header");
    for (int i = 0; i<14; i++) {
      String dashes = "----------";
      dashes = dashes.substring(0,10-scores.getString(i,0).length()-floor(log(scores.getInt(i,1)+1)/2.303f));
      if (scores.getString(i,0).equals(keyboard.nameString) && scores.getInt(i,1) == score)  {
        fill(255,235,0);
        text(scores.getString(i,0)+dashes+scores.getInt(i,1),game.BoardOrigin.x+17,game.BoardOrigin.y+140+(i*50));
      } else {
        fill(255);
        text(scores.getString(i,0)+dashes+scores.getInt(i,1),game.BoardOrigin.x+17,game.BoardOrigin.y+140+(i*50));
      }
    }

    fill(0);
     stroke(255);
     strokeWeight(4);
     rect(game.BoardOrigin.x-200,game.BoardOrigin.y+200,200,320);
     fill(255,253,0);
     textFont(d,40);
     text(keyboard.nameString,(game.BoardOrigin.x-110)-(10*(keyboard.nameString.length())),game.BoardOrigin.y+250);
     line(game.BoardOrigin.x-200,game.BoardOrigin.y+273,game.BoardOrigin.x,game.BoardOrigin.y+273);
     fill(255);
     text("SCORE",game.BoardOrigin.x-160,game.BoardOrigin.y+320);
     fill(255,253,0);
       if (score > 9) {
         text(score,(game.BoardOrigin.x-110)-(15*floor(log(score+1)/2.303f)),game.BoardOrigin.y+365);
       } else {
         text(score,game.BoardOrigin.x-110,game.BoardOrigin.y+365);
       }
     fill(255);
     text("LINES",game.BoardOrigin.x-160,game.BoardOrigin.y+440);
       if (linesCleared > 9) {
         text(linesCleared,(game.BoardOrigin.x-110)-(15*floor(log(linesCleared+1)/2.303f)),game.BoardOrigin.y+485);
       } else {
         text(linesCleared,game.BoardOrigin.x-110,game.BoardOrigin.y+485);
       }
    fill(255);
    textFont(d,56);
    text("Press ENTER to Play Again",game.BoardOrigin.x-197,game.BoardOrigin.y+BoardHeight+75);
  }
  
  public void penultimate() {
    penultimateTriggered = true;
    stage = 1;
    fallTime = 16;
    music1.stop();
    music2.loop();
    music3.stop();
  }
  
  public void finale() {
    finaleTriggered = true;
    stage = 2;
    fallTime = 7;
    background(0);
    music1.stop();
    music2.stop();
    music3.loop();
  }
  
  public void reset() {
    timer = 0;
    colorTimer = 0;
    count = 0;
    lost = 0;
    stage = 0;
    storedPiece = 0;
    score = 0;
    linesCleared = 0;
    for (int i = 0; i<5; i++) {
      upNext[i] = 0;
    }
    penultimateTriggered = false;
    finaleTriggered = false;
    yourScore = "";
   
   for(int i =0; i<3; i++) {
    keyboard.bottomSelect[i] = false;
    keyboard.gotten = false;
    keyboard.name = new StringBuilder();
    keyboard.nameString = "";
   }
    music1.stop();
    music2.stop();
    music3.stop();
    musicDeath.stop();
   setup();
  }
}
public class Piece {
  int posx;
  int posy;
  int Color;
  int strokeColor;
  int type = 0;
  
  public void init() {
    if (type==1) {
      //Line
      Color = color(0xff80ffff);
      strokeColor = color(0xff089999);
    } else if (type==2) {
      //L
      Color = color(0xff0000ff);
      strokeColor = color(0xff4545cc);
    } else if (type==3) {
      //J
      Color = color(0xffffa200);
      strokeColor = color(0xffcc8200);
    } else if (type==4) {
      //Square
      Color = color(0xffffff00);
      strokeColor = color(0xffb3b300);
    } else if (type==5) {
      //S
      Color = color(0xff00ff00);
      strokeColor = color(0xff00a100);
    } else if (type==6) {
      //T
      Color = color(0xffff00ff);
      strokeColor = color(0xffab00ab);
    } else if (type==7) {
      //Z
      Color = color(0xffff0000);
      strokeColor = color(0xffc70000);
    } else if (type==0) {
      //Blank
      Color = color(0);
    }
  }
}
public class Point {
  int x;
  int y;
  
public Point newPoint(int x, int y) {
    Point generated = new Point();
    generated.x = x;
    generated.y = y;
    return generated;
  }
}
public class Tetromino {
  Piece tile1 = new Piece();
  Piece tile2 = new Piece();
  Piece tile3 = new Piece();
  Piece tile4 = new Piece();
  boolean active;
  int type;
  int headPosX;
  int headPosY;
  int rotation;
  int solidifyNext = 100;
  
    int newvalue1x = 0;
    int newvalue1y = 0;
    int newvalue2x = 0;
    int newvalue2y = 0;
    int newvalue3x = 0;
    int newvalue3y = 0;
    int newvalue4x = 0;
    int newvalue4y = 0;
    
    Point ghost1 = new Point();
    Point ghost2 = new Point();
    Point ghost3 = new Point();
    Point ghost4 = new Point();
  
  public Tetromino newTetromino(int tetType) {
    Tetromino generated;
    generated = new Tetromino();
    generated.active = true;
    generated.type = tetType;
    
    if (generated.type==1) {
      //Line
      generated.headPosX = 0;
      generated.headPosY = 3;
      
      generated.tile1 = newPiece(generated.type,0,3);  //HEAD
      generated.tile2 = newPiece(generated.type,0,4);
      generated.tile3 = newPiece(generated.type,0,5);
      generated.tile4 = newPiece(generated.type,0,6);
      
    } else if (generated.type==2) {
      //L
      
      generated.headPosX = 0;
      generated.headPosY = 3;
      
      generated.tile1 = newPiece(generated.type,1,3);
      generated.tile2 = newPiece(generated.type,0,3);  //HEAD
      generated.tile3 = newPiece(generated.type,1,4);
      generated.tile4 = newPiece(generated.type,1,5);
    } else if (generated.type==3) {
      //J
      
      generated.headPosX = 0;
      generated.headPosY = 6;
      
      generated.tile1 = newPiece(generated.type,1,4);
      generated.tile2 = newPiece(generated.type,1,5);
      generated.tile3 = newPiece(generated.type,1,6);
      generated.tile4 = newPiece(generated.type,0,6);  //HEAD
    } else if (generated.type==4) {
      //Square
      
      generated.headPosX = 0;
      generated.headPosY = 4;
      
      generated.tile1 = newPiece(generated.type,0,4);  //HEAD
      generated.tile2 = newPiece(generated.type,0,5);
      generated.tile3 = newPiece(generated.type,1,4);
      generated.tile4 = newPiece(generated.type,1,5);
    } else if (generated.type==5) {
      //S
      
      generated.headPosX = 1;
      generated.headPosY = 5;
      
      generated.tile1 = newPiece(generated.type,1,4);
      generated.tile2 = newPiece(generated.type,1,5);  //HEAD
      generated.tile3 = newPiece(generated.type,0,5);
      generated.tile4 = newPiece(generated.type,0,6);
    } else if (generated.type==6) {
      //T
      
      generated.headPosX = 0;
      generated.headPosY = 5;
      
      generated.tile1 = newPiece(generated.type,0,5);  //HEAD
      generated.tile2 = newPiece(generated.type,1,4);
      generated.tile3 = newPiece(generated.type,1,5);
      generated.tile4 = newPiece(generated.type,1,6);
    } else if (generated.type==7) {
      //Z
      
      generated.headPosX = 1;
      generated.headPosY = 6;
      
      generated.tile1 = newPiece(generated.type,0,4);  //HEAD
      generated.tile2 = newPiece(generated.type,0,5);
      generated.tile3 = newPiece(generated.type,1,5);
      generated.tile4 = newPiece(generated.type,1,6);
    }
    
    game.upNext[4] = PApplet.parseInt(random(1,8));
    for (int i = 0; i<4; i++) {
      game.upNext[i]=game.upNext[i+1];
    }
    
    generated.solidifyNext = game.fallTime;
    return generated;
  }
  
  public void moveDown() {
    if (max(max(tile1.posx,tile2.posx,tile3.posx),tile4.posx)<19) {
      headPosX++;
      tile1.posx++;
      tile2.posx++;
      tile3.posx++;
      tile4.posx++;
      game.score++;
    } else {
      println("But it refused!");
    }
  }
  
  public void moveLeft() {
    if ((min(min(tile1.posy,tile2.posy,tile3.posy),tile4.posy)>0) && (game.OccupiedSpaces[tile1.posx][tile1.posy-1]==0 && game.OccupiedSpaces[tile2.posx][tile2.posy-1]==0 && game.OccupiedSpaces[tile3.posx][tile3.posy-1]==0 && game.OccupiedSpaces[tile4.posx][tile4.posy-1]==0)) {
      headPosY--;
      tile1.posy--;
      tile2.posy--;
      tile3.posy--;
      tile4.posy--;
    } else {
      println("But it refused!");
    }
  }
  
  public void moveRight() {
    if ((max(max(tile1.posy,tile2.posy,tile3.posy),tile4.posy)<9) && (game.OccupiedSpaces[tile1.posx][tile1.posy+1]==0 && game.OccupiedSpaces[tile2.posx][tile2.posy+1]==0 && game.OccupiedSpaces[tile3.posx][tile3.posy+1]==0 && game.OccupiedSpaces[tile4.posx][tile4.posy+1]==0)) {
      headPosY++;
      tile1.posy++;
      tile2.posy++;
      tile3.posy++;
      tile4.posy++;
    } else {
      println("But it refused!");
    }
  }
  
  public void snapDown() {
    while (game.collisionDetection(activet)==false) {
      moveDown();
    }
  }
  
  public void ghostDown() {
    if (max(max(ghost1.x,ghost2.x,ghost3.x),ghost4.x)<19) {
      ghost1.x++;
      ghost2.x++;
      ghost3.x++;
      ghost4.x++;
    }
  }
  
  public void ghost() {
    while (game.detectCollision()==false) {
      ghostDown();
    }
  }
  
  public void rotate() {
      newvalue1y = tile1.posy;
      newvalue1x = tile1.posx;
      newvalue2y = tile2.posy;
      newvalue2x = tile2.posx;
      newvalue3y = tile3.posy;
      newvalue3x = tile3.posx;
      newvalue4y = tile4.posy;
      newvalue4x = tile4.posx;
    
    if (rotation==0) {
      if (type==1) {
        //Line
        newvalue1y+=2;
        newvalue1x-=1;
        newvalue2y+=1;
        newvalue3x+=1;
        newvalue4y-=1;
        newvalue4x+=2;
        
      } else if (type==2) {
        //L
        newvalue2y+=2;
        newvalue1x-=1;
        newvalue1y+=1;
        newvalue4y-=1;
        newvalue4x+=1;
        
      } else if (type==3) {
        //J
        newvalue3x+=1;
        newvalue3y-=1;
        newvalue1x-=1;
        newvalue1y+=1;
        newvalue4x+=2;
        
      } else if (type==4) {
        //Square
        
      } else if (type==5) {
        //S
        newvalue1x-=2;
        newvalue2y-=1;
        newvalue2x-=1;
        newvalue4x+=1;
        newvalue4y-=1;
        //©2019 Dylan Speiser
      } else if (type==6) {
        //T
        newvalue1y+=1;
        newvalue1x+=1;
        newvalue2y+=1;
        newvalue2x-=1;
        newvalue4x+=1;
        newvalue4y-=1;
      } else if (type==7) {
        //Z
        newvalue1y+=1;
        newvalue1x-=1;
        newvalue3x-=1;
        newvalue3y-=1;
        newvalue4y-=2;
      } } else if (rotation==1) {
      if (type==1) {
        //Line
        newvalue1y+=1;
        newvalue1x+=2;
        newvalue2x+=1;
        newvalue3y-=1;
        newvalue4y-=2;
        newvalue4x-=1;
        
      } else if (type==2) {
        //L
        newvalue2x+=2;
        newvalue1y+=1;
        newvalue1x+=1;
        newvalue4y-=1;
        newvalue4x-=1;
        
      } else if (type==3) {
        //J
        newvalue3y-=1;
        newvalue3x-=1;
        newvalue1x+=1;
        newvalue1y+=1;
        newvalue4y-=2;
        
      } else if (type==4) {
        //Square
        
      } else if (type==5) {
        //S
        newvalue1y+=2;
        newvalue2y+=1;
        newvalue2x-=1;
        newvalue4x-=1;
        newvalue4y-=1;
      } else if (type==6) {
        //T
        newvalue2y+=1;
        newvalue2x+=1;
        newvalue4y-=1;
        newvalue4x-=1;
        newvalue1x+=1;
        newvalue1y-=1;
      } else if (type==7) {
        //Z
        newvalue1y+=1;
        newvalue1x+=1;
        newvalue3x-=1;
        newvalue3y+=1;
        newvalue4x-=2;
      } } else if (rotation==2) {
      if (type==1) {
        //Line
        newvalue1y-=2;
        newvalue1x+=1;
        newvalue2y-=1;
        newvalue3x-=1;
        newvalue4y+=1;
        newvalue4x-=2;
        
      } else if (type==2) {
        //L
        newvalue2y-=2;
        newvalue1x+=1;
        newvalue1y-=1;
        newvalue4y+=1;
        newvalue4x-=1;
        
      } else if (type==3) {
        //J
        newvalue3y+=1;
        newvalue3x-=1;
        newvalue1y-=1;
        newvalue1x+=1;
        newvalue4x-=2;
        
      } else if (type==4) {
        //Square
        
      } else if (type==5) {
        //S
        newvalue1x+=2;
        newvalue2y+=1;
        newvalue2x+=1;
        newvalue4x-=1;
        newvalue4y+=1;
      } else if (type==6) {
        //T
        newvalue4y+=1;
        newvalue4x-=1;
        newvalue1y-=1;
        newvalue1x-=1;
        newvalue2x+=1;
        newvalue2y-=1;
      } else if (type==7) {
        //Z
        newvalue1y-=1;
        newvalue1x+=1;
        newvalue3x+=1;
        newvalue3y+=1;
        newvalue4y+=2;
      } } else if (rotation==3) {
      if (type==1) {
        //Line
        newvalue1y-=1;
        newvalue1x-=2;
        newvalue2x-=1;
        newvalue3y+=1;
        newvalue4y+=2;
        newvalue4x+=1;
        
      } else if (type==2) {
        //L
        newvalue2x-=2;
        newvalue1x-=1;
        newvalue1y-=1;
        newvalue4y+=1;
        newvalue4x+=1;
        
      } else if (type==3) {
        //J
        newvalue3y+=1;
        newvalue3x+=1;
        newvalue1x-=1;
        newvalue1y-=1;
        newvalue4y+=2;
        
      } else if (type==4) {
        //Square
        
      } else if (type==5) {
        //S
        newvalue1y-=2;
        newvalue2y-=1;
        newvalue2x+=1;
        newvalue4x+=1;
        newvalue4y+=1;
      } else if (type==6) {
        //T
        newvalue4y+=1;
        newvalue4x+=1;
        newvalue2y-=1;
        newvalue2x-=1;
        newvalue1x-=1;
        newvalue1y+=1;
      } else if (type==7) {
        //Z
        newvalue1y-=1;
        newvalue1x-=1;
        newvalue3x+=1;
        newvalue3y-=1;
        newvalue4x+=2;
      }
      }
     
     if ((min(min(newvalue1x,newvalue2x,newvalue3x),newvalue4x)>=0) && (max(max(newvalue1x,newvalue2x,newvalue3x),newvalue4x)<20) && (min(min(newvalue1y,newvalue2y,newvalue3y),newvalue4y)>=0) && (max(max(newvalue1y,newvalue2y,newvalue3y),newvalue4y)<10)) {
        tile1.posy = newvalue1y;
        tile1.posx = newvalue1x;
        tile2.posy = newvalue2y;
        tile2.posx = newvalue2x;
        tile3.posy = newvalue3y;
        tile3.posx = newvalue3x;
        tile4.posy = newvalue4y;
        tile4.posx = newvalue4x;
        
       if (rotation < 3) {
         rotation++;
       } else {
         rotation=0;
       }
     } else {
        newvalue1y = tile1.posy;
        newvalue1x = tile1.posx;
        newvalue2y = tile2.posy;
        newvalue2x = tile2.posx;
        newvalue3y = tile3.posy;
        newvalue3x = tile3.posx;
        newvalue4y = tile4.posy;
        newvalue4x = tile4.posx;
     }
  }
  
  public void solidify() {
    game.OccupiedSpaces[tile1.posx][tile1.posy] = type;
    game.OccupiedSpaces[tile2.posx][tile2.posy] = type;
    game.OccupiedSpaces[tile3.posx][tile3.posy] = type;
    game.OccupiedSpaces[tile4.posx][tile4.posy] = type;
    
    activet = newTetromino(game.upNext[0]);
  }
}
public class UndertaleKeyboard {
  char capitals[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',' ',' '};
  char lowercase[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' ',' '};
  String bottom[] = {"Clear","Backspace","Done"};
  boolean bottomSelect[] = {false, false, false};
  boolean gotten = false;
  boolean doCapitals = false;
  
  Point selected = new Point();
  
  StringBuilder name = new StringBuilder();
  String nameString = "";
  
  Point positions1[][] = {
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()}
  };
  
  Point positions2[][] = {
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()},
    {new Point(), new Point(), new Point(), new Point(), new Point(), new Point(), new Point()}
  };
  
  Char capitalArray[][] = {
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()}
  };
  
  Char lowercaseArray[][] = {
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()},
    {new Char(), new Char(), new Char(), new Char(), new Char(), new Char(), new Char()}
  };
  
  public void keyboardSetup() {
    textFont(f,50);
    int counter = 0;
    selected.x = 0;
    selected.y = 0;
    for (int i=0;i<4;i++) {
      for(int j=0;j<7;j++) {
          lowercaseArray[i][j].face = lowercase[counter];
          capitalArray[i][j].face = capitals[counter];
          lowercaseArray[i][j].selected = false;
          capitalArray[i][j].selected = false;
          lowercaseArray[i][j].xindex = j;
          capitalArray[i][j].xindex = j;
          lowercaseArray[i][j].yindex = i;
          capitalArray[i][j].yindex = i;
        counter++;
      }
    }
      counter = 0;
  }
  
  public void keyboardDraw() {
    background(0);
    
    for (int i=0;i<4;i++) {
      for(int j=0;j<7;j++) {
        positions1[i][j].x = (j+2)*width/10+PApplet.parseInt(random(0,6));
        positions2[i][j].x = (j+2)*width/10+PApplet.parseInt(random(0,6));
        
        positions1[i][j].y = (i*(height/4)/4)+(height/4)+50+PApplet.parseInt(random(0,6));
        positions2[i][j].y = (i*(height/4)/4)+(height/2)+150+PApplet.parseInt(random(0,6));
      }
    }
    
    for (int i=0; i<3; i++) {
      bottomSelect[i]=false;
    }
    
    for (int i=0;i<4;i++) {
      for(int j=0;j<7;j++) {
          lowercaseArray[i][j].selected = false;
          capitalArray[i][j].selected = false;
      }
    }
    
    if (-1<selected.y && selected.y < 4) {
      capitalArray[selected.y][selected.x].selected = true;
    } else if (selected.y>-1){
      lowercaseArray[selected.y-4][selected.x].selected = true;
    }
    
    textFont(f,60);
    if (selected.y==-1) {
      bottomSelect[selected.x]=true;
    }
      for (int i=0; i<3; i++) {
        if (bottomSelect[i]) {
          fill(255,235,0);
          text(bottom[i],i*(width/4)+(3*width/16)+50,height-100);
        } else {
          fill(255);
          text(bottom[i],i*(width/4)+(3*width/16)+50,height-100);
        }
      }
      
      for (int i=0;i<4;i++) {
        for(int j=0;j<7;j++) {
          if (capitalArray[i][j].selected) {
            fill(255,235,0);
            text(capitalArray[i][j].face,positions1[i][j].x,positions1[i][j].y);
          } else {
            fill(255);
            text(capitalArray[i][j].face,positions1[i][j].x,positions1[i][j].y);
          }
          
          if (lowercaseArray[i][j].selected) {
            fill(255,235,0);
            text(lowercaseArray[i][j].face,positions2[i][j].x,positions2[i][j].y);
          } else {
            fill(255);
            text(lowercaseArray[i][j].face,positions2[i][j].x,positions2[i][j].y);
          }
        }
      }
    
    fill(255);
    textFont(f,80);
    text(nameString,7*(width/20),height/6);
    
  }
  
  public void keyboardPressed() {
    int pressed = keyCode;
    //println(keyCode);
    
    if (65 <= keyCode && keyCode <= 90 && doCapitals==true && name.length()<7) {
      name.append(PApplet.parseChar(keyCode));
      nameString = name.toString();
    } else if (65 <= keyCode && keyCode <= 90 && doCapitals==false && name.length()<7) {
      name.append(Character.toLowerCase(PApplet.parseChar(keyCode)));
      nameString = name.toString();
    }
    
    //println(Character.toLowerCase(char(keyCode)));
    
    if (pressed == 16) {
      doCapitals = true;
    }
    
    if (pressed == 38) {
        if (selected.y > 0) {
          selected.y--;
          if (selected.y==3 && selected.x>4) {
            selected.y--;
          }
        } else {
          selected.y=7;
        }
    }
    
    if (pressed == 39) {
        if (selected.x < 6 && bottomSelect[2]==false &! (selected.x>4 && (selected.y==3 || selected.y==7))) {
          selected.x++;
        }
    }
    
    if (pressed == 40) {
        if (selected.y < 8) {
          selected.y++;
          if ((selected.y==3 && selected.x>4)|| (selected.y == 7 && selected.x>4)) {
            selected.y++;
          }
        } if (selected.y == 8) {
          selected.y=-1;
          selected.x=1;
          bottomSelect[1]=true;
        }
    }
    
    if (pressed == 37 && bottomSelect[0]==false) {
        if (selected.x > 0) {
          selected.x--;
        }
    }
    
    if (pressed == 10) {
        if (-1 < selected.y && selected.y < 4 && name.length() < 7) {
          capitalArray[selected.y][selected.x].appendToString(nameString);
        } else if (selected.y >=4 && name.length() < 7) {
          lowercaseArray[selected.y%4][selected.x].appendToString(nameString);
        } else if (selected.y==-1) {
          if (selected.x == 0) {
            name = new StringBuilder();
            nameString = "";
          } else if (selected.x == 1 && name.length() > 0) {
            name.setLength(name.length()-1);
            nameString = name.toString();
          } else if (selected.x == 2) {
              game.init();
              music1.loop();
              for (int i = 0; i<4; i++) {
                game.upNext[i] = PApplet.parseInt(random(1,8));
              }
                activet = tetromino.newTetromino(PApplet.parseInt(random(1,8)));
            gotten = true;
          }
        }
        //println(nameString);
    }
  }
}

  
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Tetris__Processing_ClubFairDemo" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
